package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Theme Colors - Fresh Emerald & Sage
val EmeraldPrimaryLight = Color(0xFF0D6B56)
val EmeraldOnPrimaryLight = Color(0xFFFFFFFF)
val EmeraldPrimaryContainerLight = Color(0xFFA5F2DA)
val EmeraldOnPrimaryContainerLight = Color(0xFF002118)

val EmeraldSecondaryLight = Color(0xFF4C635B)
val EmeraldOnSecondaryLight = Color(0xFFFFFFFF)
val EmeraldSecondaryContainerLight = Color(0xFFCEE8DE)
val EmeraldOnSecondaryContainerLight = Color(0xFF082019)

val EmeraldTertiaryLight = Color(0xFF3E6373)
val EmeraldBackgroundLight = Color(0xFFF6FBF8)
val EmeraldSurfaceLight = Color(0xFFFFFFFF)
val EmeraldSurfaceVariantLight = Color(0xFFDBE5E0)
val EmeraldOutlineLight = Color(0xFF6F7975)

// Dark Theme Colors
val EmeraldPrimaryDark = Color(0xFF89D6BE)
val EmeraldOnPrimaryDark = Color(0xFF00382B)
val EmeraldPrimaryContainerDark = Color(0xFF00513F)
val EmeraldOnPrimaryContainerDark = Color(0xFFA5F2DA)

val EmeraldSecondaryDark = Color(0xFFB2CCC1)
val EmeraldOnSecondaryDark = Color(0xFF1E352D)
val EmeraldSecondaryContainerDark = Color(0xFF354B43)
val EmeraldOnSecondaryContainerDark = Color(0xFFCEE8DE)

val EmeraldTertiaryDark = Color(0xFFA5CCE0)
val EmeraldBackgroundDark = Color(0xFF111413)
val EmeraldSurfaceDark = Color(0xFF191C1B)
val EmeraldSurfaceVariantDark = Color(0xFF3F4945)
val EmeraldOutlineDark = Color(0xFF89938F)
