package com.example

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.RingtoneManager
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import java.util.Calendar
import java.util.Locale

/**
 * BroadcastReceiver triggered when a scheduled habit alarm fires.
 * Displays a high-priority notification with sound and vibration, and
 * automatically reschedules the alarm for the next day.
 */
class HabitAlarmReceiver : BroadcastReceiver() {
  override fun onReceive(context: Context, intent: Intent) {
    val habitId = intent.getStringExtra("habit_id") ?: "default"
    val habitTitle = intent.getStringExtra("habit_title") ?: "Habit Reminder"
    val habitCategory = intent.getStringExtra("habit_category") ?: "Daily Habit"
    val habitTime = intent.getStringExtra("habit_time") ?: ""

    Log.d("HabitAlarmReceiver", "Alarm fired for habit: $habitTitle at $habitTime")

    // Display the notification
    HabitNotificationHelper.showNotification(
      context = context,
      id = habitId.hashCode(),
      title = "⏰ Time for $habitTitle!",
      message = "Stay consistent with your $habitCategory routine ($habitTime). Tap to check off!"
    )

    // Reschedule for tomorrow same time
    if (habitTime.isNotEmpty()) {
      HabitNotificationHelper.scheduleNextDayAlarm(context, habitId, habitTitle, habitCategory, habitTime)
    }
  }
}

/**
 * Helper object for scheduling real daily alarms and delivering notifications.
 */
object HabitNotificationHelper {
  const val CHANNEL_ID = "habit_daily_reminders"
  const val CHANNEL_NAME = "Daily Habit Reminders"

  fun createNotificationChannel(context: Context) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
      val notificationManager =
        context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
      val existingChannel = notificationManager.getNotificationChannel(CHANNEL_ID)
      if (existingChannel == null) {
        val channel = NotificationChannel(
          CHANNEL_ID,
          CHANNEL_NAME,
          NotificationManager.IMPORTANCE_HIGH
        ).apply {
          description = "Notifications and alarms for daily habit check-ins"
          enableVibration(true)
          vibrationPattern = longArrayOf(0, 250, 150, 250)
          enableLights(true)
        }
        notificationManager.createNotificationChannel(channel)
      }
    }
  }

  fun showNotification(context: Context, id: Int, title: String, message: String) {
    createNotificationChannel(context)

    val notificationIntent = Intent(context, MainActivity::class.java).apply {
      flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
    }
    val pendingIntent = PendingIntent.getActivity(
      context,
      id,
      notificationIntent,
      PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    val defaultSoundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)

    val notification = NotificationCompat.Builder(context, CHANNEL_ID)
      .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
      .setContentTitle(title)
      .setContentText(message)
      .setStyle(NotificationCompat.BigTextStyle().bigText(message))
      .setPriority(NotificationCompat.PRIORITY_HIGH)
      .setCategory(NotificationCompat.CATEGORY_ALARM)
      .setAutoCancel(true)
      .setSound(defaultSoundUri)
      .setVibrate(longArrayOf(0, 250, 150, 250))
      .setContentIntent(pendingIntent)
      .build()

    val notificationManager =
      context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    notificationManager.notify(id, notification)
  }

  /**
   * Parses time string like "07:00 AM" or "08:30 PM" into (hour, minute) in 24-hr format.
   */
  fun parseTime(timeStr: String): Pair<Int, Int>? {
    return try {
      val parts = timeStr.trim().split(" ")
      val timeParts = parts[0].split(":")
      var hour = timeParts[0].toInt()
      val minute = timeParts[1].toInt()
      val amPm = if (parts.size > 1) parts[1].uppercase(Locale.getDefault()) else "AM"

      if (amPm == "PM" && hour < 12) hour += 12
      if (amPm == "AM" && hour == 12) hour = 0

      Pair(hour, minute)
    } catch (e: Exception) {
      null
    }
  }

  /**
   * Programmatically schedules an exact daily alarm using Android AlarmManager.
   */
  fun scheduleHabitAlarm(
    context: Context,
    habitId: String,
    habitTitle: String,
    habitCategory: String,
    habitTime: String
  ): Boolean {
    val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return false
    val (hour, minute) = parseTime(habitTime) ?: Pair(8, 0)

    val now = Calendar.getInstance()
    val target = Calendar.getInstance().apply {
      set(Calendar.HOUR_OF_DAY, hour)
      set(Calendar.MINUTE, minute)
      set(Calendar.SECOND, 0)
      set(Calendar.MILLISECOND, 0)
    }

    // If target time already passed today, schedule for tomorrow
    if (target.before(now)) {
      target.add(Calendar.DAY_OF_YEAR, 1)
    }

    val intent = Intent(context, HabitAlarmReceiver::class.java).apply {
      putExtra("habit_id", habitId)
      putExtra("habit_title", habitTitle)
      putExtra("habit_category", habitCategory)
      putExtra("habit_time", habitTime)
    }

    val pendingIntent = PendingIntent.getBroadcast(
      context,
      habitId.hashCode(),
      intent,
      PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    try {
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        if (alarmManager.canScheduleExactAlarms()) {
          alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, target.timeInMillis, pendingIntent)
        } else {
          alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, target.timeInMillis, pendingIntent)
        }
      } else {
        alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, target.timeInMillis, pendingIntent)
      }
      Log.d("HabitNotificationHelper", "Scheduled alarm for $habitTitle at ${target.time}")
      return true
    } catch (e: SecurityException) {
      // Fallback if exact alarm not granted
      alarmManager.set(AlarmManager.RTC_WAKEUP, target.timeInMillis, pendingIntent)
      return true
    } catch (e: Exception) {
      Log.e("HabitNotificationHelper", "Error scheduling alarm", e)
      return false
    }
  }

  fun scheduleNextDayAlarm(
    context: Context,
    habitId: String,
    habitTitle: String,
    habitCategory: String,
    habitTime: String
  ) {
    val (hour, minute) = parseTime(habitTime) ?: Pair(8, 0)
    val target = Calendar.getInstance().apply {
      add(Calendar.DAY_OF_YEAR, 1)
      set(Calendar.HOUR_OF_DAY, hour)
      set(Calendar.MINUTE, minute)
      set(Calendar.SECOND, 0)
      set(Calendar.MILLISECOND, 0)
    }

    val intent = Intent(context, HabitAlarmReceiver::class.java).apply {
      putExtra("habit_id", habitId)
      putExtra("habit_title", habitTitle)
      putExtra("habit_category", habitCategory)
      putExtra("habit_time", habitTime)
    }

    val pendingIntent = PendingIntent.getBroadcast(
      context,
      habitId.hashCode(),
      intent,
      PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
    try {
      alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, target.timeInMillis, pendingIntent)
    } catch (e: Exception) {
      alarmManager.set(AlarmManager.RTC_WAKEUP, target.timeInMillis, pendingIntent)
    }
  }

  fun cancelHabitAlarm(context: Context, habitId: String) {
    val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
    val intent = Intent(context, HabitAlarmReceiver::class.java)
    val pendingIntent = PendingIntent.getBroadcast(
      context,
      habitId.hashCode(),
      intent,
      PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )
    alarmManager.cancel(pendingIntent)
    pendingIntent.cancel()
    Log.d("HabitNotificationHelper", "Cancelled alarm for habit $habitId")
  }
}
