package com.example

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Context
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Cake
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.FormatQuote
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Bedtime
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.Medication
import androidx.compose.material.icons.filled.Mood
import androidx.compose.material.icons.filled.NightlightRound
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.TaskAlt
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material.icons.filled.WbTwilight
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.MyApplicationTheme
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.Period
import java.time.format.DateTimeFormatter
import java.util.Locale
import java.util.UUID

/**
 * Habit Data Model representing a daily trackable activity.
 */
data class Habit(
  val id: String = UUID.randomUUID().toString(),
  val title: String,
  val time: String = "07:00 AM",
  val category: String,
  val isCompleted: Boolean = false,
  val streakDays: Int = 1
)

/**
 * Daily Task Data Model for one-off checklist items.
 */
data class DailyTask(
  val id: String = UUID.randomUUID().toString(),
  val title: String,
  val isCompleted: Boolean = false
)

/**
 * Note Data Model for multiple important notes.
 */
data class ImportantNote(
  val id: String = UUID.randomUUID().toString(),
  val title: String,
  val content: String,
  val category: String = "General",
  val updatedAt: String = ""
)

/**
 * Motivational Quote Model.
 */
data class Quote(val text: String, val author: String)

/**
 * Medicine Item Model representing scheduled daily medicine doses across 3 slots:
 * - Morning (Sokal)
 * - Afternoon (Dupur)
 * - Night (Rat)
 */
data class MedicineItem(
  val id: String = UUID.randomUUID().toString(),
  val name: String,
  val dosage: String = "1 Tablet",
  val slot: String = "Morning (Sokal)",
  val isTaken: Boolean = false
)

/**
 * Storage helper for Habits.
 */
object HabitStorage {
  private const val PREFS_NAME = "habit_prefs"
  private const val KEY_HABITS = "saved_habits_v2"

  fun getDefaultHabits(): List<Habit> = listOf(
    Habit(id = "1", title = "Drink 2L Water", time = "08:00 AM", category = "Health", isCompleted = true, streakDays = 5),
    Habit(id = "2", title = "Morning Yoga / Run", time = "07:00 AM", category = "Fitness", isCompleted = false, streakDays = 3),
    Habit(id = "3", title = "Deep Work Sprint", time = "10:00 AM", category = "Productivity", isCompleted = false, streakDays = 12),
    Habit(id = "4", title = "Read 20 Pages", time = "09:30 PM", category = "Learning", isCompleted = false, streakDays = 6),
    Habit(id = "5", title = "Mindful Meditation", time = "06:30 AM", category = "Mindfulness", isCompleted = true, streakDays = 7),
    Habit(id = "6", title = "Review Daily Budget", time = "08:30 PM", category = "Finance", isCompleted = false, streakDays = 4)
  )

  fun saveHabits(context: Context, habits: List<Habit>) {
    try {
      val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
      val jsonArray = JSONArray()
      for (habit in habits) {
        val obj = JSONObject().apply {
          put("id", habit.id)
          put("title", habit.title)
          put("time", habit.time)
          put("category", habit.category)
          put("isCompleted", habit.isCompleted)
          put("streakDays", habit.streakDays)
        }
        jsonArray.put(obj)
      }
      prefs.edit().putString(KEY_HABITS, jsonArray.toString()).apply()
    } catch (e: Exception) {
      e.printStackTrace()
    }
  }

  fun loadHabits(context: Context): List<Habit> {
    val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    val jsonString = prefs.getString(KEY_HABITS, null) ?: return emptyList()
    val list = mutableListOf<Habit>()
    try {
      val jsonArray = JSONArray(jsonString)
      for (i in 0 until jsonArray.length()) {
        val obj = jsonArray.getJSONObject(i)
        list.add(
          Habit(
            id = obj.optString("id", UUID.randomUUID().toString()),
            title = obj.optString("title", ""),
            time = obj.optString("time", "07:00 AM"),
            category = obj.optString("category", "Health"),
            isCompleted = obj.optBoolean("isCompleted", false),
            streakDays = obj.optInt("streakDays", 1)
          )
        )
      }
    } catch (e: Exception) {
      e.printStackTrace()
    }
    return list
  }
}

/**
 * Storage helper for Daily Tasks checklist.
 */
object TaskStorage {
  private const val PREFS_NAME = "habit_prefs"
  private const val KEY_TASKS = "saved_daily_tasks_v1"

  fun getDefaultTasks(): List<DailyTask> = listOf(
    DailyTask(id = "t1", title = "Plan top 3 high-leverage priorities", isCompleted = true),
    DailyTask(id = "t2", title = "Clear inbox down to zero", isCompleted = false),
    DailyTask(id = "t3", title = "Prepare gym clothes & water bottle for tomorrow", isCompleted = false),
    DailyTask(id = "t4", title = "15-minute evening digital detox walk", isCompleted = false)
  )

  fun saveTasks(context: Context, tasks: List<DailyTask>) {
    try {
      val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
      val jsonArray = JSONArray()
      for (task in tasks) {
        val obj = JSONObject().apply {
          put("id", task.id)
          put("title", task.title)
          put("isCompleted", task.isCompleted)
        }
        jsonArray.put(obj)
      }
      prefs.edit().putString(KEY_TASKS, jsonArray.toString()).apply()
    } catch (e: Exception) {
      e.printStackTrace()
    }
  }

  fun loadTasks(context: Context): List<DailyTask> {
    val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    val jsonString = prefs.getString(KEY_TASKS, null) ?: return emptyList()
    val list = mutableListOf<DailyTask>()
    try {
      val jsonArray = JSONArray(jsonString)
      for (i in 0 until jsonArray.length()) {
        val obj = jsonArray.getJSONObject(i)
        list.add(
          DailyTask(
            id = obj.optString("id", UUID.randomUUID().toString()),
            title = obj.optString("title", ""),
            isCompleted = obj.optBoolean("isCompleted", false)
          )
        )
      }
    } catch (e: Exception) {
      e.printStackTrace()
    }
    return list
  }
}

/**
 * Storage helper for Important Notes.
 */
object NoteStorage {
  private const val PREFS_NAME = "habit_prefs"
  private const val KEY_NOTES = "saved_important_notes_v3"

  fun getDefaultNotes(): List<ImportantNote> = listOf(
    ImportantNote(
      id = "1",
      title = "Morning Mindset & Priorities",
      content = "1. Start with gratitude and deep breathing.\n2. Tackle the most critical task before email.\n3. Drink 500ml water before caffeine.",
      category = "Priority",
      updatedAt = "Today, 08:30 AM"
    ),
    ImportantNote(
      id = "2",
      title = "Habit Building: The 2-Minute Rule",
      content = "When starting a new habit, it should take less than two minutes to do. Scaling down makes starting effortless.",
      category = "Idea",
      updatedAt = "Yesterday, 04:15 PM"
    ),
    ImportantNote(
      id = "3",
      title = "Weekly Reflection & Gratitude",
      content = "Consistency triumphs over intensity. Even 15 minutes of dedicated daily study compounds massively over 30 days.",
      category = "Reflection",
      updatedAt = "Sep 12, 09:20 PM"
    )
  )

  fun saveNotes(context: Context, notes: List<ImportantNote>) {
    try {
      val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
      val jsonArray = JSONArray()
      for (note in notes) {
        val obj = JSONObject().apply {
          put("id", note.id)
          put("title", note.title)
          put("content", note.content)
          put("category", note.category)
          put("updatedAt", note.updatedAt)
        }
        jsonArray.put(obj)
      }
      prefs.edit().putString(KEY_NOTES, jsonArray.toString()).apply()
    } catch (e: Exception) {
      e.printStackTrace()
    }
  }

  fun loadNotes(context: Context): List<ImportantNote> {
    val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    val jsonString = prefs.getString(KEY_NOTES, null) ?: return emptyList()
    val list = mutableListOf<ImportantNote>()
    try {
      val jsonArray = JSONArray(jsonString)
      for (i in 0 until jsonArray.length()) {
        val obj = jsonArray.getJSONObject(i)
        list.add(
          ImportantNote(
            id = obj.optString("id", UUID.randomUUID().toString()),
            title = obj.optString("title", ""),
            content = obj.optString("content", ""),
            category = obj.optString("category", "General"),
            updatedAt = obj.optString("updatedAt", "")
          )
        )
      }
    } catch (e: Exception) {
      e.printStackTrace()
    }
    return list
  }
}

/**
 * Storage helper for Daily Medicine Tracker.
 */
object MedicineStorage {
  private const val PREFS_NAME = "habit_prefs"
  private const val KEY_MEDICINES = "saved_medicines_v2"

  fun getDefaultMedicines(): List<MedicineItem> = listOf(
    MedicineItem(id = "m1", name = "Vitamin C & D3", dosage = "1 Tablet • After breakfast", slot = "Morning (Sokal)", isTaken = true),
    MedicineItem(id = "m2", name = "Omega-3 Fish Oil", dosage = "1 Capsule • Post lunch", slot = "Afternoon (Dupur)", isTaken = false),
    MedicineItem(id = "m3", name = "Calcium & Magnesium", dosage = "1 Tablet • Before sleep", slot = "Night (Rat)", isTaken = false)
  )

  fun saveMedicines(context: Context, medicines: List<MedicineItem>) {
    try {
      val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
      val jsonArray = JSONArray()
      for (med in medicines) {
        val obj = JSONObject().apply {
          put("id", med.id)
          put("name", med.name)
          put("dosage", med.dosage)
          put("slot", med.slot)
          put("isTaken", med.isTaken)
        }
        jsonArray.put(obj)
      }
      prefs.edit().putString(KEY_MEDICINES, jsonArray.toString()).apply()
    } catch (e: Exception) {
      e.printStackTrace()
    }
  }

  fun loadMedicines(context: Context): List<MedicineItem> {
    val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    val jsonString = prefs.getString(KEY_MEDICINES, null) ?: return emptyList()
    val list = mutableListOf<MedicineItem>()
    try {
      val jsonArray = JSONArray(jsonString)
      for (i in 0 until jsonArray.length()) {
        val obj = jsonArray.getJSONObject(i)
        list.add(
          MedicineItem(
            id = obj.optString("id", UUID.randomUUID().toString()),
            name = obj.optString("name", ""),
            dosage = obj.optString("dosage", "1 Tablet"),
            slot = obj.optString("slot", "Morning (Sokal)"),
            isTaken = obj.optBoolean("isTaken", false)
          )
        )
      }
    } catch (e: Exception) {
      e.printStackTrace()
    }
    return list
  }
}

/**
 * Calculates user age in full years from an ISO date string (YYYY-MM-DD).
 */
fun calculateAge(dobIso: String): Int? {
  return try {
    val dob = LocalDate.parse(dobIso)
    val now = LocalDate.now()
    Period.between(dob, now).years.coerceAtLeast(0)
  } catch (e: Exception) {
    null
  }
}

/**
 * Formats an ISO date string (YYYY-MM-DD) into readable format (MMM d, yyyy).
 */
fun formatDob(dobIso: String): String {
  return try {
    val dob = LocalDate.parse(dobIso)
    dob.format(DateTimeFormatter.ofPattern("MMM d, yyyy", Locale.getDefault()))
  } catch (e: Exception) {
    dobIso
  }
}

/**
 * Material 3 Bottom Navigation 5 distinct tabs.
 */
enum class AppTab(val title: String, val icon: ImageVector, val tag: String) {
  HOME("Home", Icons.Default.Home, "nav_home_tab"),
  HABITS("Habits", Icons.Default.CheckCircle, "nav_habits_tab"),
  TASKS("Tasks & Mood", Icons.Default.TaskAlt, "nav_tasks_tab"),
  NOTES("Notes", Icons.Default.EditNote, "nav_notes_tab"),
  SETTINGS("Settings", Icons.Default.Settings, "nav_settings_tab")
}

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      val context = LocalContext.current
      val sharedPrefs = remember { context.getSharedPreferences("habit_prefs", Context.MODE_PRIVATE) }
      var isDarkMode by remember {
        mutableStateOf(sharedPrefs.getBoolean("user_dark_mode", true))
      }

      MyApplicationTheme(darkTheme = isDarkMode) {
        DailyHabitCheckerApp(
          isDarkMode = isDarkMode,
          onToggleDarkMode = { newDark ->
            isDarkMode = newDark
            sharedPrefs.edit().putBoolean("user_dark_mode", newDark).apply()
          }
        )
      }
    }
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DailyHabitCheckerApp(
  isDarkMode: Boolean = true,
  onToggleDarkMode: (Boolean) -> Unit = {}
) {
  val context = LocalContext.current
  val snackbarHostState = remember { SnackbarHostState() }
  val scope = rememberCoroutineScope()
  val sharedPrefs = remember { context.getSharedPreferences("habit_prefs", Context.MODE_PRIVATE) }

  // Current active Bottom Navigation Tab (0: Home, 1: Habits, 2: Tasks & Mood, 3: Notes, 4: Settings)
  var selectedTabIndex by remember { mutableIntStateOf(0) }

  // Persisted Habits List
  val habits = remember {
    val saved = HabitStorage.loadHabits(context)
    mutableStateListOf<Habit>().apply {
      if (saved.isNotEmpty()) {
        addAll(saved)
      } else {
        addAll(HabitStorage.getDefaultHabits())
        HabitStorage.saveHabits(context, this)
      }
    }
  }

  // Persisted Daily Tasks Checklist
  val tasks = remember {
    val savedTasks = TaskStorage.loadTasks(context)
    mutableStateListOf<DailyTask>().apply {
      if (savedTasks.isNotEmpty()) {
        addAll(savedTasks)
      } else {
        addAll(TaskStorage.getDefaultTasks())
        TaskStorage.saveTasks(context, this)
      }
    }
  }

  // Persisted Notes List
  val notes = remember {
    val savedNotes = NoteStorage.loadNotes(context)
    mutableStateListOf<ImportantNote>().apply {
      if (savedNotes.isNotEmpty()) {
        addAll(savedNotes)
      } else {
        addAll(NoteStorage.getDefaultNotes())
        NoteStorage.saveNotes(context, this)
      }
    }
  }

  // Persisted Medicines List (Morning Sokal, Afternoon Dupur, Night Rat)
  val medicines = remember {
    val savedMeds = MedicineStorage.loadMedicines(context)
    mutableStateListOf<MedicineItem>().apply {
      if (savedMeds.isNotEmpty()) {
        addAll(savedMeds)
      } else {
        addAll(MedicineStorage.getDefaultMedicines())
        MedicineStorage.saveMedicines(context, this)
      }
    }
  }

  // Profile Name & DOB state (persisted in SharedPreferences)
  var profileName by remember {
    mutableStateOf(sharedPrefs.getString("user_profile_name", "Habit Champion") ?: "Habit Champion")
  }
  var profileDob by remember {
    mutableStateOf(sharedPrefs.getString("user_profile_dob", "1998-05-20") ?: "1998-05-20")
  }

  // Water Tracker glasses (persisted)
  var waterGlasses by remember {
    mutableIntStateOf(sharedPrefs.getInt("daily_water_glasses", 4))
  }

  // Mood Tracker (persisted)
  var selectedMood by remember {
    mutableStateOf(sharedPrefs.getString("user_daily_mood", "😊 Good") ?: "😊 Good")
  }

  // Dialog states
  var showAddHabitDialog by remember { mutableStateOf(false) }
  var habitToDelete by remember { mutableStateOf<Habit?>(null) }

  // Runtime permission launcher for POST_NOTIFICATIONS
  val notificationPermissionLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.RequestPermission(),
    onResult = { /* Permission handled */ }
  )

  // Initialize notification channel, request permission, and schedule alarms for existing habits
  LaunchedEffect(Unit) {
    HabitNotificationHelper.createNotificationChannel(context)
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
      notificationPermissionLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
    }
    // Programmatically schedule daily exact alarm for each active habit
    for (habit in habits) {
      HabitNotificationHelper.scheduleHabitAlarm(
        context = context,
        habitId = habit.id,
        habitTitle = habit.title,
        habitCategory = habit.category,
        habitTime = habit.time
      )
    }
  }

  Scaffold(
    modifier = Modifier
      .fillMaxSize()
      .testTag("daily_habit_checker_screen"),
    snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
    topBar = {
      TopAppBar(
        title = {
          Column {
            Text(
              text = when (selectedTabIndex) {
                0 -> "Daily Habit Checker"
                1 -> "Habit Manager"
                2 -> "Daily Tasks & Mood"
                3 -> "Important Notes"
                else -> "App Settings"
              },
              style = MaterialTheme.typography.titleLarge.copy(
                fontWeight = FontWeight.Bold,
                fontSize = 20.sp
              )
            )
            Text(
              text = when (selectedTabIndex) {
                0 -> "Consistency is the key to progress"
                1 -> "${habits.size} habits scheduled with alarms"
                2 -> "${tasks.count { it.isCompleted }}/${tasks.size} tasks done • Mood: $selectedMood"
                3 -> "${notes.size} notes stored locally"
                else -> "Profile, preferences & app info"
              },
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        },
        actions = {
          if (selectedTabIndex == 0 || selectedTabIndex == 1) {
            Surface(
              shape = RoundedCornerShape(16.dp),
              color = MaterialTheme.colorScheme.primaryContainer,
              modifier = Modifier.padding(end = 12.dp)
            ) {
              Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
              ) {
                Icon(
                  imageVector = Icons.Default.LocalFireDepartment,
                  contentDescription = "Streak",
                  tint = MaterialTheme.colorScheme.primary,
                  modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                  text = "5d Streak",
                  style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
                  color = MaterialTheme.colorScheme.onPrimaryContainer
                )
              }
            }
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(
          containerColor = MaterialTheme.colorScheme.surface
        )
      )
    },
    bottomBar = {
      NavigationBar(
        modifier = Modifier.testTag("bottom_nav_bar"),
        containerColor = MaterialTheme.colorScheme.surface,
        tonalElevation = 8.dp
      ) {
        AppTab.values().forEachIndexed { index, tab ->
          val isSelected = selectedTabIndex == index
          NavigationBarItem(
            selected = isSelected,
            onClick = { selectedTabIndex = index },
            icon = {
              Icon(
                imageVector = tab.icon,
                contentDescription = tab.title
              )
            },
            label = {
              Text(
                text = tab.title,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                fontSize = 11.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
              )
            },
            modifier = Modifier.testTag(tab.tag),
            colors = NavigationBarItemDefaults.colors(
              selectedIconColor = MaterialTheme.colorScheme.primary,
              selectedTextColor = MaterialTheme.colorScheme.primary,
              indicatorColor = MaterialTheme.colorScheme.primaryContainer,
              unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
              unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
            )
          )
        }
      }
    },
    floatingActionButton = {
      // FAB (+) on Habits tab
      if (selectedTabIndex == 1) {
        FloatingActionButton(
          onClick = { showAddHabitDialog = true },
          containerColor = MaterialTheme.colorScheme.primary,
          contentColor = MaterialTheme.colorScheme.onPrimary,
          modifier = Modifier.testTag("add_habit_fab")
        ) {
          Icon(
            imageVector = Icons.Default.Add,
            contentDescription = "Add Habit"
          )
        }
      }
    }
  ) { innerPadding ->
    Box(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding)
    ) {
      when (selectedTabIndex) {
        // Tab 1: Home Tab
        0 -> HomeTabScreen(
          profileName = profileName,
          profileDob = profileDob,
          habits = habits,
          waterGlasses = waterGlasses,
          onUpdateWater = { newCount ->
            waterGlasses = newCount.coerceIn(0, 16)
            sharedPrefs.edit().putInt("daily_water_glasses", waterGlasses).apply()
          },
          onNavigateToHabits = { selectedTabIndex = 1 },
          medicines = medicines,
          onToggleMedicine = { med, isTaken ->
            val index = medicines.indexOfFirst { it.id == med.id }
            if (index != -1) {
              medicines[index] = medicines[index].copy(isTaken = isTaken)
              MedicineStorage.saveMedicines(context, medicines)
              scope.launch {
                val msg = if (isTaken) "Taken: ${med.name} (${med.slot}) 💊" else "Marked not taken: ${med.name}"
                snackbarHostState.showSnackbar(msg)
              }
            }
          },
          onAddMedicine = { name, dosage, slot ->
            val newMed = MedicineItem(
              name = name,
              dosage = dosage,
              slot = slot,
              isTaken = false
            )
            medicines.add(newMed)
            MedicineStorage.saveMedicines(context, medicines)
            scope.launch {
              snackbarHostState.showSnackbar("Added medicine: $name to $slot ✅")
            }
          },
          onDeleteMedicine = { med ->
            medicines.remove(med)
            MedicineStorage.saveMedicines(context, medicines)
            scope.launch {
              snackbarHostState.showSnackbar("Removed: ${med.name}")
            }
          }
        )

        // Tab 2: Habits Tab
        1 -> HabitsTabScreen(
          habits = habits,
          onToggleHabit = { habit, isChecked ->
            val index = habits.indexOfFirst { it.id == habit.id }
            if (index != -1) {
              habits[index] = habits[index].copy(isCompleted = isChecked)
              HabitStorage.saveHabits(context, habits)
              scope.launch {
                val message = if (isChecked) "Completed: ${habit.title} 🎉" else "Marked incomplete: ${habit.title}"
                snackbarHostState.showSnackbar(message)
              }
            }
          },
          onDeleteHabit = { habit ->
            habitToDelete = habit
          }
        )

        // Tab 3: Tasks & Mood Tab
        2 -> TasksAndMoodTabScreen(
          tasks = tasks,
          selectedMood = selectedMood,
          onToggleTask = { task, isChecked ->
            val index = tasks.indexOfFirst { it.id == task.id }
            if (index != -1) {
              tasks[index] = tasks[index].copy(isCompleted = isChecked)
              TaskStorage.saveTasks(context, tasks)
            }
          },
          onAddTask = { title ->
            val newTask = DailyTask(title = title, isCompleted = false)
            tasks.add(0, newTask)
            TaskStorage.saveTasks(context, tasks)
            scope.launch {
              snackbarHostState.showSnackbar("Task added: $title")
            }
          },
          onDeleteTask = { task ->
            tasks.remove(task)
            TaskStorage.saveTasks(context, tasks)
            scope.launch {
              snackbarHostState.showSnackbar("Task deleted: ${task.title}")
            }
          },
          onSelectMood = { mood ->
            selectedMood = mood
            sharedPrefs.edit().putString("user_daily_mood", mood).apply()
            scope.launch {
              snackbarHostState.showSnackbar("Mood logged: $mood ✨")
            }
          }
        )

        // Tab 4: Important Notes Tab
        3 -> ImportantNoteTabContent(
          notes = notes,
          onAddNote = { newNote ->
            notes.add(0, newNote)
            NoteStorage.saveNotes(context, notes)
            scope.launch {
              snackbarHostState.showSnackbar("Note added: ${newNote.title} 📝")
            }
          },
          onUpdateNote = { updatedNote ->
            val index = notes.indexOfFirst { it.id == updatedNote.id }
            if (index != -1) {
              notes[index] = updatedNote
              NoteStorage.saveNotes(context, notes)
              scope.launch {
                snackbarHostState.showSnackbar("Note updated! 📝")
              }
            }
          },
          onDeleteNote = { note ->
            notes.remove(note)
            NoteStorage.saveNotes(context, notes)
            scope.launch {
              snackbarHostState.showSnackbar("Deleted note: ${note.title}")
            }
          }
        )

        // Tab 5: Settings Tab
        4 -> SettingTabContent(
          currentProfileName = profileName,
          currentProfileDob = profileDob,
          isDarkMode = isDarkMode,
          onSaveProfile = { newName, newDob ->
            profileName = newName
            profileDob = newDob
            sharedPrefs.edit()
              .putString("user_profile_name", newName)
              .putString("user_profile_dob", newDob)
              .apply()
            scope.launch {
              snackbarHostState.showSnackbar("Profile & DOB saved successfully! ✅")
            }
          },
          onToggleDarkMode = onToggleDarkMode
        )
      }
    }
  }

  // Delete Habit Confirmation Dialog
  habitToDelete?.let { habit ->
    AlertDialog(
      onDismissRequest = { habitToDelete = null },
      title = {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(
            imageVector = Icons.Default.DeleteOutline,
            contentDescription = "Delete Habit",
            tint = MaterialTheme.colorScheme.error,
            modifier = Modifier.size(24.dp)
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(text = "Delete Habit?", fontWeight = FontWeight.Bold)
        }
      },
      text = {
        Text("Are you sure you want to remove \"${habit.title}\" and cancel its daily scheduled alarm?")
      },
      confirmButton = {
        Button(
          onClick = {
            HabitNotificationHelper.cancelHabitAlarm(context, habit.id)
            habits.remove(habit)
            HabitStorage.saveHabits(context, habits)
            habitToDelete = null
            scope.launch {
              snackbarHostState.showSnackbar("Deleted habit & cancelled alarm: ${habit.title}")
            }
          },
          colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
          modifier = Modifier.testTag("confirm_delete_habit_button")
        ) {
          Text("Delete", color = MaterialTheme.colorScheme.onError, fontWeight = FontWeight.Bold)
        }
      },
      dismissButton = {
        TextButton(
          onClick = { habitToDelete = null },
          modifier = Modifier.testTag("cancel_delete_habit_button")
        ) {
          Text("Cancel")
        }
      }
    )
  }

  // Add Habit Dialog (available on Habits Tab)
  if (showAddHabitDialog) {
    AddHabitDialog(
      context = context,
      onDismiss = { showAddHabitDialog = false },
      onConfirm = { title, category, time ->
        val newHabit = Habit(
          title = title,
          category = category,
          time = time,
          isCompleted = false,
          streakDays = 1
        )
        habits.add(newHabit)
        HabitStorage.saveHabits(context, habits)
        // Programmatically schedule exact daily alarm/notification for habit time
        HabitNotificationHelper.scheduleHabitAlarm(
          context = context,
          habitId = newHabit.id,
          habitTitle = newHabit.title,
          habitCategory = newHabit.category,
          habitTime = newHabit.time
        )
        showAddHabitDialog = false
        scope.launch {
          snackbarHostState.showSnackbar("Habit added! Daily alarm set for $time ⏰")
        }
      }
    )
  }
}

/**
 * 1. HOME TAB SCREEN:
 * - Dynamic Date & Day header, personalized greeting with Profile Name and Age.
 * - Streak Counter & Daily Progress Bar.
 * - Daily Motivation Quote Card with shuffle action.
 * - Quick Water Intake Tracker (glass counter with +/- buttons).
 */
@Composable
fun HomeTabScreen(
  profileName: String,
  profileDob: String,
  habits: List<Habit>,
  waterGlasses: Int,
  onUpdateWater: (Int) -> Unit,
  onNavigateToHabits: () -> Unit,
  medicines: List<MedicineItem>,
  onToggleMedicine: (MedicineItem, Boolean) -> Unit,
  onAddMedicine: (String, String, String) -> Unit,
  onDeleteMedicine: (MedicineItem) -> Unit
) {
  var showAddMedDialog by remember { mutableStateOf(false) }
  var preselectedSlot by remember { mutableStateOf("Morning (Sokal)") }

  val userAge = calculateAge(profileDob)
  val todayDate = remember {
    val now = LocalDate.now()
    val dayName = now.dayOfWeek.getDisplayName(java.time.format.TextStyle.FULL, Locale.getDefault())
    val formatter = DateTimeFormatter.ofPattern("MMMM d, yyyy", Locale.getDefault())
    dayName to now.format(formatter)
  }

  val totalHabits = habits.size
  val completedHabits = habits.count { it.isCompleted }
  val habitProgress = if (totalHabits > 0) completedHabits.toFloat() / totalHabits else 0f
  val animatedProgress by animateFloatAsState(
    targetValue = habitProgress,
    animationSpec = tween(durationMillis = 400),
    label = "HomeProgressAnimation"
  )

  // Motivational Quotes
  val quotes = remember {
    listOf(
      Quote("We are what we repeatedly do. Excellence, then, is not an act, but a habit.", "Will Durant"),
      Quote("Small daily improvements over time lead to stunning compound results.", "Robin Sharma"),
      Quote("You do not rise to the level of your goals. You fall to the level of your systems.", "James Clear"),
      Quote("Discipline is choosing between what you want now and what you want most.", "Abraham Lincoln"),
      Quote("The secret of getting ahead is getting started.", "Mark Twain"),
      Quote("Continuous effort—not strength or intelligence—is the key to unlocking our potential.", "Winston Churchill")
    )
  }
  var quoteIndex by remember { mutableIntStateOf(0) }
  val currentQuote = quotes[quoteIndex % quotes.size]

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .testTag("home_tab_scroll_view"),
    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 10.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp)
  ) {
    // 1. Dynamic Date & Greeting Header Card
    item {
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .testTag("home_header_card"),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(
          containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f)
        )
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text(
                text = "Welcome back, $profileName! 👋",
                style = MaterialTheme.typography.titleMedium.copy(
                  fontWeight = FontWeight.Bold,
                  fontSize = 19.sp
                ),
                color = MaterialTheme.colorScheme.onSurface
              )
              Spacer(modifier = Modifier.height(4.dp))
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                  imageVector = Icons.Default.Cake,
                  contentDescription = "DOB",
                  tint = MaterialTheme.colorScheme.primary,
                  modifier = Modifier.size(15.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                  text = if (userAge != null) {
                    "${formatDob(profileDob)} • $userAge yrs old"
                  } else {
                    formatDob(profileDob)
                  },
                  style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Medium),
                  color = MaterialTheme.colorScheme.primary
                )
              }
            }

            Surface(
              shape = RoundedCornerShape(10.dp),
              color = MaterialTheme.colorScheme.surface
            ) {
              Row(
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                Icon(
                  imageVector = Icons.Default.CalendarMonth,
                  contentDescription = "Date",
                  tint = MaterialTheme.colorScheme.primary,
                  modifier = Modifier.size(15.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                  text = "${todayDate.first}, ${todayDate.second}",
                  style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                  color = MaterialTheme.colorScheme.onSurface
                )
              }
            }
          }
        }
      }
    }

    // 2. Streak & Daily Progress Card
    item {
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .testTag("home_progress_card"),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(
          containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
        )
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(
                imageVector = Icons.Default.CheckCircle,
                contentDescription = "Daily Progress",
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(22.dp)
              )
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = "Daily Habit Progress",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
              )
            }
            Text(
              text = "${(habitProgress * 100).toInt()}% Done",
              style = MaterialTheme.typography.titleSmall.copy(
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
              )
            )
          }

          Spacer(modifier = Modifier.height(10.dp))

          LinearProgressIndicator(
            progress = { animatedProgress },
            modifier = Modifier
              .fillMaxWidth()
              .height(10.dp)
              .clip(RoundedCornerShape(5.dp)),
            color = MaterialTheme.colorScheme.primary,
            trackColor = MaterialTheme.colorScheme.surfaceVariant
          )

          Spacer(modifier = Modifier.height(8.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = "$completedHabits of $totalHabits habits completed today",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            TextButton(
              onClick = onNavigateToHabits,
              contentPadding = PaddingValues(horizontal = 4.dp, vertical = 0.dp)
            ) {
              Text("View Habits →", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
          }
        }
      }
    }

    // 3. Daily Motivation Quote Card
    item {
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .testTag("quote_card"),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(
          containerColor = MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.35f)
        )
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(
                imageVector = Icons.Default.FormatQuote,
                contentDescription = "Daily Quote",
                tint = MaterialTheme.colorScheme.tertiary,
                modifier = Modifier.size(24.dp)
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = "Daily Motivation",
                style = MaterialTheme.typography.titleSmall.copy(
                  fontWeight = FontWeight.Bold,
                  color = MaterialTheme.colorScheme.tertiary
                )
              )
            }

            IconButton(
              onClick = { quoteIndex++ },
              modifier = Modifier.size(28.dp)
            ) {
              Icon(
                imageVector = Icons.Default.Refresh,
                contentDescription = "Shuffle quote",
                tint = MaterialTheme.colorScheme.tertiary,
                modifier = Modifier.size(18.dp)
              )
            }
          }

          Spacer(modifier = Modifier.height(8.dp))

          Text(
            text = "“${currentQuote.text}”",
            style = MaterialTheme.typography.bodyMedium.copy(fontStyle = androidx.compose.ui.text.font.FontStyle.Italic),
            color = MaterialTheme.colorScheme.onTertiaryContainer
          )

          Spacer(modifier = Modifier.height(6.dp))

          Text(
            text = "— ${currentQuote.author}",
            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
            color = MaterialTheme.colorScheme.tertiary,
            modifier = Modifier.align(Alignment.End)
          )
        }
      }
    }

    // 4. Quick Water Intake Tracker (glass counter with +/- buttons)
    item {
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .testTag("water_intake_card"),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(
          containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.4f)
        )
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Box(
                modifier = Modifier
                  .size(36.dp)
                  .clip(CircleShape)
                  .background(MaterialTheme.colorScheme.secondary),
                contentAlignment = Alignment.Center
              ) {
                Icon(
                  imageVector = Icons.Default.WaterDrop,
                  contentDescription = "Water Tracker",
                  tint = MaterialTheme.colorScheme.onSecondary,
                  modifier = Modifier.size(20.dp)
                )
              }
              Spacer(modifier = Modifier.width(10.dp))
              Column {
                Text(
                  text = "Daily Water Intake",
                  style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
                Text(
                  text = "Goal: 8 Glasses (2.0 Liters)",
                  style = MaterialTheme.typography.bodySmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant
                )
              }
            }

            // Glass Count Badge
            Surface(
              shape = RoundedCornerShape(12.dp),
              color = MaterialTheme.colorScheme.secondaryContainer
            ) {
              Text(
                text = "$waterGlasses / 8 Glasses",
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onSecondaryContainer,
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
              )
            }
          }

          Spacer(modifier = Modifier.height(14.dp))

          // Visual glass indicators (8 dots/icons)
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            for (i in 1..8) {
              val isFilled = i <= waterGlasses
              Surface(
                shape = CircleShape,
                color = if (isFilled) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.surfaceVariant,
                modifier = Modifier
                  .size(28.dp)
                  .clickable { onUpdateWater(i) }
              ) {
                Box(contentAlignment = Alignment.Center) {
                  Icon(
                    imageVector = Icons.Default.WaterDrop,
                    contentDescription = "Glass $i",
                    tint = if (isFilled) MaterialTheme.colorScheme.onSecondary else MaterialTheme.colorScheme.outline,
                    modifier = Modifier.size(16.dp)
                  )
                }
              }
            }
          }

          Spacer(modifier = Modifier.height(14.dp))

          // Increment / Decrement Buttons
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            FilledTonalButton(
              onClick = { onUpdateWater(waterGlasses - 1) },
              modifier = Modifier
                .weight(1f)
                .testTag("decrease_water_button"),
              shape = RoundedCornerShape(12.dp),
              enabled = waterGlasses > 0
            ) {
              Icon(Icons.Default.Remove, contentDescription = "Minus 1 glass", modifier = Modifier.size(18.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text("Minus Glass")
            }

            Button(
              onClick = { onUpdateWater(waterGlasses + 1) },
              modifier = Modifier
                .weight(1f)
                .testTag("increase_water_button"),
              shape = RoundedCornerShape(12.dp)
            ) {
              Icon(Icons.Default.Add, contentDescription = "Add 1 glass", modifier = Modifier.size(18.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text("Add Glass")
            }
          }
        }
      }
    }

    // 5. Daily Medicine Tracker Card (strictly right below Water Intake Tracker)
    item {
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .testTag("medicine_tracker_card"),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(
          containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
        )
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          // Card Header
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              modifier = Modifier.weight(1f)
            ) {
              Box(
                modifier = Modifier
                  .size(36.dp)
                  .clip(CircleShape)
                  .background(MaterialTheme.colorScheme.primary),
                contentAlignment = Alignment.Center
              ) {
                Icon(
                  imageVector = Icons.Default.Medication,
                  contentDescription = "Medicine Tracker",
                  tint = MaterialTheme.colorScheme.onPrimary,
                  modifier = Modifier.size(20.dp)
                )
              }
              Spacer(modifier = Modifier.width(10.dp))
              Column {
                Text(
                  text = "Daily Medicine Tracker",
                  style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
                Text(
                  text = "3 Slots: Morning, Afternoon & Night",
                  style = MaterialTheme.typography.bodySmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant
                )
              }
            }

            // Status badge & Add button
            Row(verticalAlignment = Alignment.CenterVertically) {
              val takenCount = medicines.count { it.isTaken }
              Surface(
                shape = RoundedCornerShape(12.dp),
                color = if (takenCount == medicines.size && medicines.isNotEmpty())
                  MaterialTheme.colorScheme.primaryContainer
                else
                  MaterialTheme.colorScheme.secondaryContainer
              ) {
                Text(
                  text = "$takenCount/${medicines.size} Taken",
                  style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                  color = MaterialTheme.colorScheme.onSecondaryContainer,
                  modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                )
              }
              Spacer(modifier = Modifier.width(6.dp))
              IconButton(
                onClick = {
                  preselectedSlot = "Morning (Sokal)"
                  showAddMedDialog = true
                },
                modifier = Modifier.size(32.dp)
              ) {
                Icon(
                  imageVector = Icons.Default.Add,
                  contentDescription = "Add Medicine",
                  tint = MaterialTheme.colorScheme.primary,
                  modifier = Modifier.size(20.dp)
                )
              }
            }
          }

          Spacer(modifier = Modifier.height(14.dp))

          // 3 Clear Daily Slots: Morning (Sokal), Afternoon (Dupur), Night (Rat)
          val slots = listOf(
            Triple("Morning (Sokal)", Icons.Default.WbTwilight, Color(0xFFE65100)),
            Triple("Afternoon (Dupur)", Icons.Default.WbSunny, Color(0xFFF57F17)),
            Triple("Night (Rat)", Icons.Default.Bedtime, Color(0xFF3949AB))
          )

          slots.forEachIndexed { index, (slotName, icon, accentColor) ->
            if (index > 0) {
              HorizontalDivider(
                modifier = Modifier.padding(vertical = 10.dp),
                color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
              )
            }

            val slotMeds = medicines.filter { it.slot == slotName }

            Column(modifier = Modifier.fillMaxWidth()) {
              // Slot Header
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Icon(
                    imageVector = icon,
                    contentDescription = slotName,
                    tint = accentColor,
                    modifier = Modifier.size(18.dp)
                  )
                  Spacer(modifier = Modifier.width(6.dp))
                  Text(
                    text = slotName,
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface
                  )
                  Spacer(modifier = Modifier.width(6.dp))
                  Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = accentColor.copy(alpha = 0.12f)
                  ) {
                    Text(
                      text = "${slotMeds.count { it.isTaken }}/${slotMeds.size}",
                      style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
                      color = accentColor,
                      modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                  }
                }

                TextButton(
                  onClick = {
                    preselectedSlot = slotName
                    showAddMedDialog = true
                  },
                  contentPadding = PaddingValues(horizontal = 4.dp, vertical = 0.dp)
                ) {
                  Text("+ Add", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
              }

              Spacer(modifier = Modifier.height(6.dp))

              if (slotMeds.isEmpty()) {
                Surface(
                  shape = RoundedCornerShape(10.dp),
                  color = MaterialTheme.colorScheme.surface.copy(alpha = 0.6f),
                  modifier = Modifier.fillMaxWidth()
                ) {
                  Text(
                    text = "No medicines scheduled for $slotName",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                  )
                }
              } else {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                  slotMeds.forEach { med ->
                    Surface(
                      shape = RoundedCornerShape(10.dp),
                      color = MaterialTheme.colorScheme.surface,
                      tonalElevation = 1.dp,
                      modifier = Modifier.fillMaxWidth()
                    ) {
                      Row(
                        modifier = Modifier
                          .fillMaxWidth()
                          .padding(horizontal = 8.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                      ) {
                        Checkbox(
                          checked = med.isTaken,
                          onCheckedChange = { isChecked ->
                            onToggleMedicine(med, isChecked)
                          },
                          colors = CheckboxDefaults.colors(
                            checkedColor = MaterialTheme.colorScheme.primary
                          )
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Column(modifier = Modifier.weight(1f)) {
                          Text(
                            text = med.name,
                            style = MaterialTheme.typography.bodyMedium.copy(
                              fontWeight = FontWeight.SemiBold,
                              textDecoration = if (med.isTaken) TextDecoration.LineThrough else null
                            ),
                            color = if (med.isTaken)
                              MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                            else
                              MaterialTheme.colorScheme.onSurface
                          )
                          Text(
                            text = med.dosage,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                          )
                        }
                        IconButton(
                          onClick = { onDeleteMedicine(med) },
                          modifier = Modifier.size(28.dp)
                        ) {
                          Icon(
                            imageVector = Icons.Default.DeleteOutline,
                            contentDescription = "Delete ${med.name}",
                            tint = MaterialTheme.colorScheme.error.copy(alpha = 0.7f),
                            modifier = Modifier.size(16.dp)
                          )
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }

    item {
      Spacer(modifier = Modifier.height(20.dp))
    }
  }

  // Add Medicine Dialog
  if (showAddMedDialog) {
    var medName by remember { mutableStateOf("") }
    var medDosage by remember { mutableStateOf("1 Tablet") }
    var medSlot by remember { mutableStateOf(preselectedSlot) }
    val slotOptions = listOf("Morning (Sokal)", "Afternoon (Dupur)", "Night (Rat)")

    AlertDialog(
      onDismissRequest = { showAddMedDialog = false },
      title = {
        Text("Add Scheduled Medicine", fontWeight = FontWeight.Bold)
      },
      text = {
        Column(
          modifier = Modifier.fillMaxWidth(),
          verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
          OutlinedTextField(
            value = medName,
            onValueChange = { medName = it },
            label = { Text("Medicine Name") },
            placeholder = { Text("e.g., Paracetamol, Vitamin C") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
          )

          OutlinedTextField(
            value = medDosage,
            onValueChange = { medDosage = it },
            label = { Text("Dosage / Instructions") },
            placeholder = { Text("e.g., 1 Tablet • After meal") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
          )

          Text(
            text = "Daily Slot:",
            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
          )

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
          ) {
            slotOptions.forEach { slot ->
              val isSelected = medSlot == slot
              FilterChip(
                selected = isSelected,
                onClick = { medSlot = slot },
                label = {
                  Text(
                    text = when (slot) {
                      "Morning (Sokal)" -> "Morning"
                      "Afternoon (Dupur)" -> "Afternoon"
                      else -> "Night"
                    },
                    fontSize = 12.sp
                  )
                }
              )
            }
          }
        }
      },
      confirmButton = {
        Button(
          onClick = {
            if (medName.isNotBlank()) {
              onAddMedicine(medName.trim(), medDosage.trim(), medSlot)
              showAddMedDialog = false
            }
          },
          enabled = medName.isNotBlank()
        ) {
          Text("Add Medicine")
        }
      },
      dismissButton = {
        TextButton(onClick = { showAddMedDialog = false }) {
          Text("Cancel")
        }
      }
    )
  }
}

/**
 * 2. HABITS TAB SCREEN:
 * Full Habit Manager with category filter, delete option, scheduled time,
 * dynamic progress calculation, and FAB (+) to add new habits with real notification alarms.
 */
@Composable
fun HabitsTabScreen(
  habits: List<Habit>,
  onToggleHabit: (Habit, Boolean) -> Unit,
  onDeleteHabit: (Habit) -> Unit
) {
  var selectedCategory by remember { mutableStateOf("All") }
  val categories = listOf("All", "Health", "Fitness", "Productivity", "Learning", "Mindfulness", "Finance")

  val filteredHabits = remember(habits.size, selectedCategory, habits.toList()) {
    if (selectedCategory == "All") habits
    else habits.filter { it.category.equals(selectedCategory, ignoreCase = true) }
  }

  val total = habits.size
  val completed = habits.count { it.isCompleted }

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .testTag("habits_tab_list"),
    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 10.dp),
    verticalArrangement = Arrangement.spacedBy(10.dp)
  ) {
    // Summary Banner
    item {
      Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
          containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)
        ),
        modifier = Modifier.fillMaxWidth()
      ) {
        Row(
          modifier = Modifier.padding(14.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Column {
            Text(
              text = "Habit Schedule & Alarms",
              style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
              color = MaterialTheme.colorScheme.onPrimaryContainer
            )
            Text(
              text = "$completed of $total finished today • Daily reminders active",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
            )
          }
          Surface(
            shape = RoundedCornerShape(10.dp),
            color = MaterialTheme.colorScheme.primary
          ) {
            Text(
              text = "$total Habits",
              style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
              color = MaterialTheme.colorScheme.onPrimary,
              modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
            )
          }
        }
      }
    }

    // Category Filter Chips
    item {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        categories.forEach { category ->
          val isSelected = selectedCategory == category
          Surface(
            shape = RoundedCornerShape(10.dp),
            color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
            modifier = Modifier
              .clickable { selectedCategory = category }
              .testTag("habit_filter_$category")
          ) {
            Text(
              text = category,
              style = MaterialTheme.typography.labelMedium.copy(
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
              ),
              color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
              modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
            )
          }
        }
      }
    }

    if (filteredHabits.isEmpty()) {
      item {
        Card(
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
          ),
          modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 20.dp)
        ) {
          Column(
            modifier = Modifier
              .padding(24.dp)
              .fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            Icon(
              imageVector = Icons.Default.CheckCircle,
              contentDescription = "No habits",
              tint = MaterialTheme.colorScheme.primary,
              modifier = Modifier.size(44.dp)
            )
            Text(
              text = "No Habits in this category",
              style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )
            Text(
              text = "Tap the + button below to create and schedule your daily habit!",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }
      }
    } else {
      items(
        items = filteredHabits,
        key = { it.id }
      ) { habit ->
        HabitListItem(
          habit = habit,
          onToggle = { isChecked -> onToggleHabit(habit, isChecked) },
          onDelete = { onDeleteHabit(habit) }
        )
      }
    }

    item {
      Spacer(modifier = Modifier.height(72.dp))
    }
  }
}

/**
 * Single Habit Item Card with Checkbox, Time, Category, Streak, and Delete button.
 */
@Composable
fun HabitListItem(
  habit: Habit,
  onToggle: (Boolean) -> Unit,
  onDelete: () -> Unit,
  modifier: Modifier = Modifier
) {
  val animatedBg by animateColorAsState(
    targetValue = if (habit.isCompleted) {
      MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f)
    } else {
      MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
    },
    label = "HabitCardBgAnimation"
  )

  Card(
    modifier = modifier
      .fillMaxWidth()
      .testTag("habit_card_${habit.id}"),
    shape = RoundedCornerShape(14.dp),
    colors = CardDefaults.cardColors(containerColor = animatedBg),
    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 12.dp, vertical = 10.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      // Checkbox
      Checkbox(
        checked = habit.isCompleted,
        onCheckedChange = onToggle,
        colors = CheckboxDefaults.colors(
          checkedColor = MaterialTheme.colorScheme.primary,
          uncheckedColor = MaterialTheme.colorScheme.outline
        ),
        modifier = Modifier.testTag("checkbox_${habit.id}")
      )

      Spacer(modifier = Modifier.width(6.dp))

      // Habit Details
      Column(
        modifier = Modifier.weight(1f)
      ) {
        Text(
          text = habit.title,
          style = MaterialTheme.typography.titleSmall.copy(
            fontWeight = FontWeight.Bold,
            fontSize = 15.sp,
            textDecoration = if (habit.isCompleted) TextDecoration.LineThrough else null
          ),
          color = if (habit.isCompleted) {
            MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
          } else {
            MaterialTheme.colorScheme.onSurface
          },
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
          modifier = Modifier.testTag("habit_title_${habit.id}")
        )

        Spacer(modifier = Modifier.height(4.dp))

        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          // Time badge with alarm icon
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              imageVector = Icons.Default.AccessTime,
              contentDescription = "Time",
              tint = MaterialTheme.colorScheme.primary,
              modifier = Modifier.size(12.dp)
            )
            Spacer(modifier = Modifier.width(3.dp))
            Text(
              text = habit.time,
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.primary
            )
          }

          // Category Badge
          Surface(
            shape = RoundedCornerShape(6.dp),
            color = MaterialTheme.colorScheme.surfaceVariant
          ) {
            Text(
              text = habit.category,
              style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
              color = MaterialTheme.colorScheme.onSurfaceVariant,
              modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
            )
          }

          // Streak Badge
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              imageVector = Icons.Default.LocalFireDepartment,
              contentDescription = "Streak",
              tint = MaterialTheme.colorScheme.error,
              modifier = Modifier.size(12.dp)
            )
            Spacer(modifier = Modifier.width(2.dp))
            Text(
              text = "${habit.streakDays}d",
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }
      }

      // Delete Icon Button
      IconButton(
        onClick = onDelete,
        modifier = Modifier
          .size(36.dp)
          .testTag("delete_habit_${habit.id}")
      ) {
        Icon(
          imageVector = Icons.Default.DeleteOutline,
          contentDescription = "Delete habit",
          tint = MaterialTheme.colorScheme.error,
          modifier = Modifier.size(20.dp)
        )
      }
    }
  }
}

/**
 * 3. TASKS & MOOD TAB SCREEN:
 * - Daily To-Do Checklist (one-off tasks to add, complete, delete).
 * - Daily Mood Tracker (quick emoji selector with reflection advice).
 */
@Composable
fun TasksAndMoodTabScreen(
  tasks: List<DailyTask>,
  selectedMood: String,
  onToggleTask: (DailyTask, Boolean) -> Unit,
  onAddTask: (String) -> Unit,
  onDeleteTask: (DailyTask) -> Unit,
  onSelectMood: (String) -> Unit
) {
  var newTaskTitle by remember { mutableStateOf("") }

  val moodOptions = listOf(
    "🤩 Energetic",
    "😊 Good",
    "😌 Calm",
    "😐 Neutral",
    "😔 Down",
    "😫 Stressed"
  )

  val moodAdvice = when {
    selectedMood.contains("Energetic") -> "High energy day! Tackle your most challenging deep-work project first."
    selectedMood.contains("Good") -> "Great mindset! Keep the momentum going across your habits."
    selectedMood.contains("Calm") -> "Peace of mind is your superpower. Maintain steady, unhurried focus."
    selectedMood.contains("Neutral") -> "A steady day. Focus on consistency over speed."
    selectedMood.contains("Down") -> "Be gentle with yourself. Taking even one small step is a great victory."
    selectedMood.contains("Stressed") -> "Take 5 deep breaths, drink a glass of water, and step away from screens."
    else -> "Take each moment one breath at a time."
  }

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .testTag("tasks_and_mood_screen"),
    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 10.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp)
  ) {
    // 1. Daily Mood Tracker Section
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(
          containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f)
        )
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(
            verticalAlignment = Alignment.CenterVertically
          ) {
            Icon(
              imageVector = Icons.Default.Mood,
              contentDescription = "Mood Tracker",
              tint = MaterialTheme.colorScheme.primary,
              modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = "Daily Mood Tracker",
              style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )
          }

          Spacer(modifier = Modifier.height(10.dp))

          // Mood Emoji Selector Chips
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            moodOptions.forEach { mood ->
              val isSelected = selectedMood == mood
              Surface(
                shape = RoundedCornerShape(12.dp),
                color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surface,
                modifier = Modifier
                  .clickable { onSelectMood(mood) }
                  .testTag("mood_chip_$mood")
              ) {
                Text(
                  text = mood,
                  style = MaterialTheme.typography.bodyMedium.copy(
                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                  ),
                  color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
                  modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                )
              }
            }
          }

          Spacer(modifier = Modifier.height(10.dp))

          Surface(
            shape = RoundedCornerShape(10.dp),
            color = MaterialTheme.colorScheme.surface.copy(alpha = 0.8f)
          ) {
            Text(
              text = "💡 $moodAdvice",
              style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Medium),
              color = MaterialTheme.colorScheme.onSurface,
              modifier = Modifier.padding(10.dp)
            )
          }
        }
      }
    }

    // 2. Daily To-Do Checklist Header & Input
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(
          containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
        )
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(
                imageVector = Icons.Default.TaskAlt,
                contentDescription = "Tasks",
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(22.dp)
              )
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = "Daily To-Do Checklist",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
              )
            }
            Text(
              text = "${tasks.count { it.isCompleted }}/${tasks.size} Done",
              style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
              color = MaterialTheme.colorScheme.primary
            )
          }

          Spacer(modifier = Modifier.height(12.dp))

          // Add Task Input Row
          Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            OutlinedTextField(
              value = newTaskTitle,
              onValueChange = { newTaskTitle = it },
              placeholder = { Text("Add a one-off daily task...") },
              singleLine = true,
              modifier = Modifier
                .weight(1f)
                .testTag("add_task_input"),
              shape = RoundedCornerShape(12.dp)
            )

            Button(
              onClick = {
                if (newTaskTitle.trim().isNotEmpty()) {
                  onAddTask(newTaskTitle.trim())
                  newTaskTitle = ""
                }
              },
              shape = RoundedCornerShape(12.dp),
              modifier = Modifier.testTag("add_task_button")
            ) {
              Icon(Icons.Default.Add, contentDescription = "Add Task")
            }
          }
        }
      }
    }

    // To-Do Checklist Items
    if (tasks.isEmpty()) {
      item {
        Card(
          shape = RoundedCornerShape(14.dp),
          colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
          ),
          modifier = Modifier.fillMaxWidth()
        ) {
          Box(
            modifier = Modifier
              .padding(24.dp)
              .fillMaxWidth(),
            contentAlignment = Alignment.Center
          ) {
            Text(
              text = "No pending tasks for today! Great job!",
              style = MaterialTheme.typography.bodyMedium,
              color = MaterialTheme.colorScheme.outline
            )
          }
        }
      }
    } else {
      items(
        items = tasks,
        key = { it.id }
      ) { task ->
        Card(
          shape = RoundedCornerShape(12.dp),
          colors = CardDefaults.cardColors(
            containerColor = if (task.isCompleted) {
              MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.25f)
            } else {
              MaterialTheme.colorScheme.surface
            }
          ),
          elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
          modifier = Modifier
            .fillMaxWidth()
            .testTag("task_item_${task.id}")
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Checkbox(
              checked = task.isCompleted,
              onCheckedChange = { isChecked -> onToggleTask(task, isChecked) },
              colors = CheckboxDefaults.colors(checkedColor = MaterialTheme.colorScheme.primary),
              modifier = Modifier.testTag("task_checkbox_${task.id}")
            )

            Text(
              text = task.title,
              style = MaterialTheme.typography.bodyMedium.copy(
                fontWeight = if (task.isCompleted) FontWeight.Normal else FontWeight.Medium,
                textDecoration = if (task.isCompleted) TextDecoration.LineThrough else null
              ),
              color = if (task.isCompleted) {
                MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
              } else {
                MaterialTheme.colorScheme.onSurface
              },
              modifier = Modifier.weight(1f)
            )

            IconButton(
              onClick = { onDeleteTask(task) },
              modifier = Modifier
                .size(32.dp)
                .testTag("delete_task_${task.id}")
            ) {
              Icon(
                imageVector = Icons.Default.DeleteOutline,
                contentDescription = "Delete Task",
                tint = MaterialTheme.colorScheme.error,
                modifier = Modifier.size(18.dp)
              )
            }
          }
        }
      }
    }

    item {
      Spacer(modifier = Modifier.height(24.dp))
    }
  }
}

/**
 * 4. IMPORTANT NOTE TAB:
 * Multi-note notebook manager with "+ Add Note", category filtering,
 * editing, and deleting notes locally stored in SharedPreferences.
 */
@Composable
fun ImportantNoteTabContent(
  notes: List<ImportantNote>,
  onAddNote: (ImportantNote) -> Unit,
  onUpdateNote: (ImportantNote) -> Unit,
  onDeleteNote: (ImportantNote) -> Unit
) {
  var selectedCategoryFilter by remember { mutableStateOf("All") }
  var showNoteEditorDialog by remember { mutableStateOf(false) }
  var noteToEdit by remember { mutableStateOf<ImportantNote?>(null) }
  var noteToDelete by remember { mutableStateOf<ImportantNote?>(null) }

  val filterCategories = listOf("All", "Priority", "Idea", "Reflection", "Gratitude", "General")

  val filteredNotes = remember(notes.size, selectedCategoryFilter, notes.toList()) {
    if (selectedCategoryFilter == "All") {
      notes
    } else {
      notes.filter { it.category.equals(selectedCategoryFilter, ignoreCase = true) }
    }
  }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .padding(horizontal = 16.dp, vertical = 10.dp)
      .testTag("important_notes_tab_content"),
    verticalArrangement = Arrangement.spacedBy(10.dp)
  ) {
    // Header Banner with "+ Add Note" Button
    Card(
      shape = RoundedCornerShape(16.dp),
      colors = CardDefaults.cardColors(
        containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)
      ),
      modifier = Modifier.fillMaxWidth()
    ) {
      Row(
        modifier = Modifier.padding(14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier.weight(1f)
        ) {
          Box(
            modifier = Modifier
              .size(42.dp)
              .clip(RoundedCornerShape(12.dp))
              .background(MaterialTheme.colorScheme.primary),
            contentAlignment = Alignment.Center
          ) {
            Icon(
              imageVector = Icons.Default.EditNote,
              contentDescription = "Notes",
              tint = MaterialTheme.colorScheme.onPrimary,
              modifier = Modifier.size(24.dp)
            )
          }
          Spacer(modifier = Modifier.width(12.dp))
          Column {
            Text(
              text = "Notes Manager",
              style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
              color = MaterialTheme.colorScheme.onPrimaryContainer
            )
            Text(
              text = "${notes.size} notes stored locally",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
            )
          }
        }

        Button(
          onClick = {
            noteToEdit = null
            showNoteEditorDialog = true
          },
          modifier = Modifier.testTag("add_note_button"),
          shape = RoundedCornerShape(12.dp)
        ) {
          Icon(Icons.Default.Add, contentDescription = "Add Note", modifier = Modifier.size(18.dp))
          Spacer(modifier = Modifier.width(4.dp))
          Text("Add Note", fontWeight = FontWeight.Bold)
        }
      }
    }

    // Category Filter Chips
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .horizontalScroll(rememberScrollState()),
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      filterCategories.forEach { category ->
        val isSelected = selectedCategoryFilter == category
        Surface(
          shape = RoundedCornerShape(10.dp),
          color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
          modifier = Modifier
            .clickable { selectedCategoryFilter = category }
            .testTag("filter_chip_$category")
        ) {
          Text(
            text = category,
            style = MaterialTheme.typography.labelMedium.copy(
              fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
            ),
            color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
          )
        }
      }
    }

    // Notes List
    if (filteredNotes.isEmpty()) {
      Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
          containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)
        ),
        modifier = Modifier
          .fillMaxWidth()
          .padding(vertical = 24.dp)
      ) {
        Column(
          modifier = Modifier
            .padding(28.dp)
            .fillMaxWidth(),
          horizontalAlignment = Alignment.CenterHorizontally,
          verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          Icon(
            imageVector = Icons.Default.Description,
            contentDescription = "No Notes",
            tint = MaterialTheme.colorScheme.outline,
            modifier = Modifier.size(48.dp)
          )
          Text(
            text = if (selectedCategoryFilter == "All") "No Notes Found" else "No $selectedCategoryFilter Notes",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
          )
          Text(
            text = "Tap '+ Add Note' above to record key priorities, ideas, or daily reflections.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
      }
    } else {
      LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(bottom = 24.dp)
      ) {
        items(
          items = filteredNotes,
          key = { it.id }
        ) { note ->
          ImportantNoteItemCard(
            note = note,
            onEdit = {
              noteToEdit = note
              showNoteEditorDialog = true
            },
            onDelete = {
              noteToDelete = note
            }
          )
        }
      }
    }
  }

  // Add / Edit Note Dialog
  if (showNoteEditorDialog) {
    NoteEditorDialog(
      initialNote = noteToEdit,
      onDismiss = { showNoteEditorDialog = false },
      onSave = { title, content, category ->
        val nowFormatted = LocalDateTime.now()
          .format(DateTimeFormatter.ofPattern("MMM d, h:mm a", Locale.getDefault()))
        if (noteToEdit != null) {
          onUpdateNote(
            noteToEdit!!.copy(
              title = title,
              content = content,
              category = category,
              updatedAt = nowFormatted
            )
          )
        } else {
          onAddNote(
            ImportantNote(
              title = title,
              content = content,
              category = category,
              updatedAt = nowFormatted
            )
          )
        }
        showNoteEditorDialog = false
      }
    )
  }

  // Delete Note Confirmation Dialog
  noteToDelete?.let { note ->
    AlertDialog(
      onDismissRequest = { noteToDelete = null },
      title = {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(
            imageVector = Icons.Default.DeleteOutline,
            contentDescription = "Delete Note",
            tint = MaterialTheme.colorScheme.error,
            modifier = Modifier.size(24.dp)
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text("Delete Note?", fontWeight = FontWeight.Bold)
        }
      },
      text = {
        Text("Are you sure you want to delete note \"${note.title}\"? This action will remove it permanently.")
      },
      confirmButton = {
        Button(
          onClick = {
            onDeleteNote(note)
            noteToDelete = null
          },
          colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
          modifier = Modifier.testTag("confirm_delete_note_button")
        ) {
          Text("Delete", color = MaterialTheme.colorScheme.onError, fontWeight = FontWeight.Bold)
        }
      },
      dismissButton = {
        TextButton(
          onClick = { noteToDelete = null },
          modifier = Modifier.testTag("cancel_delete_note_button")
        ) {
          Text("Cancel")
        }
      }
    )
  }
}

/**
 * Single Important Note Item Card with Edit & Delete actions.
 */
@Composable
fun ImportantNoteItemCard(
  note: ImportantNote,
  onEdit: () -> Unit,
  onDelete: () -> Unit,
  modifier: Modifier = Modifier
) {
  Card(
    modifier = modifier
      .fillMaxWidth()
      .testTag("note_card_${note.id}")
      .clickable { onEdit() },
    shape = RoundedCornerShape(14.dp),
    colors = CardDefaults.cardColors(
      containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
    ),
    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Surface(
          shape = RoundedCornerShape(8.dp),
          color = when (note.category.lowercase()) {
            "priority" -> MaterialTheme.colorScheme.errorContainer
            "idea" -> MaterialTheme.colorScheme.tertiaryContainer
            "gratitude" -> MaterialTheme.colorScheme.secondaryContainer
            "reflection" -> MaterialTheme.colorScheme.primaryContainer
            else -> MaterialTheme.colorScheme.surface
          }
        ) {
          Text(
            text = note.category,
            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
            color = when (note.category.lowercase()) {
              "priority" -> MaterialTheme.colorScheme.onErrorContainer
              "idea" -> MaterialTheme.colorScheme.onTertiaryContainer
              "gratitude" -> MaterialTheme.colorScheme.onSecondaryContainer
              "reflection" -> MaterialTheme.colorScheme.onPrimaryContainer
              else -> MaterialTheme.colorScheme.onSurface
            },
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
          )
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
          if (note.updatedAt.isNotBlank()) {
            Text(
              text = note.updatedAt,
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.outline
            )
            Spacer(modifier = Modifier.width(4.dp))
          }
          IconButton(
            onClick = onEdit,
            modifier = Modifier
              .size(32.dp)
              .testTag("edit_note_${note.id}")
          ) {
            Icon(
              imageVector = Icons.Default.Edit,
              contentDescription = "Edit note",
              tint = MaterialTheme.colorScheme.primary,
              modifier = Modifier.size(18.dp)
            )
          }
          IconButton(
            onClick = onDelete,
            modifier = Modifier
              .size(32.dp)
              .testTag("delete_note_${note.id}")
          ) {
            Icon(
              imageVector = Icons.Default.DeleteOutline,
              contentDescription = "Delete note",
              tint = MaterialTheme.colorScheme.error,
              modifier = Modifier.size(18.dp)
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(6.dp))

      Text(
        text = note.title,
        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
        color = MaterialTheme.colorScheme.onSurface,
        modifier = Modifier.testTag("note_title_${note.id}")
      )

      if (note.content.isNotBlank()) {
        Spacer(modifier = Modifier.height(4.dp))
        Text(
          text = note.content,
          style = MaterialTheme.typography.bodyMedium,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
          maxLines = 4,
          overflow = TextOverflow.Ellipsis
        )
      }
    }
  }
}

/**
 * Add / Edit Note Dialog with Category selector and Inspiration Prompts.
 */
@Composable
fun NoteEditorDialog(
  initialNote: ImportantNote?,
  onDismiss: () -> Unit,
  onSave: (title: String, content: String, category: String) -> Unit
) {
  var title by remember { mutableStateOf(initialNote?.title ?: "") }
  var content by remember { mutableStateOf(initialNote?.content ?: "") }
  var category by remember { mutableStateOf(initialNote?.category ?: "Priority") }

  val categories = listOf("Priority", "Idea", "Reflection", "Gratitude", "General")
  val promptChips = listOf("💡 Key Idea", "🎯 Priority", "🧘 Gratitude", "📝 Daily Reflection", "📌 Action Item")

  AlertDialog(
    onDismissRequest = onDismiss,
    title = {
      Text(
        text = if (initialNote != null) "Edit Note" else "New Important Note",
        fontWeight = FontWeight.Bold
      )
    },
    text = {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        OutlinedTextField(
          value = title,
          onValueChange = { title = it },
          label = { Text("Note Title") },
          placeholder = { Text("e.g. Daily Top 3 Goals") },
          singleLine = true,
          modifier = Modifier
            .fillMaxWidth()
            .testTag("note_title_input"),
          shape = RoundedCornerShape(12.dp)
        )

        Text(
          text = "Category: $category",
          style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
        )
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState()),
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          categories.forEach { cat ->
            val isSelected = category.equals(cat, ignoreCase = true)
            Surface(
              shape = RoundedCornerShape(8.dp),
              color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
              modifier = Modifier.clickable { category = cat }
            ) {
              Text(
                text = cat,
                style = MaterialTheme.typography.labelSmall.copy(
                  fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                ),
                color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
              )
            }
          }
        }

        Text(
          text = "Insert Quick Prompt",
          style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
        )
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState()),
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          promptChips.forEach { prompt ->
            Surface(
              shape = RoundedCornerShape(8.dp),
              color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f),
              modifier = Modifier.clickable {
                val prefix = if (content.isEmpty() || content.endsWith("\n")) "" else "\n"
                content = "$content$prefix$prompt: "
              }
            ) {
              Text(
                text = prompt,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
              )
            }
          }
        }

        OutlinedTextField(
          value = content,
          onValueChange = { content = it },
          label = { Text("Note Content") },
          placeholder = { Text("Write your thoughts, goals, reflections, or action items...") },
          minLines = 5,
          maxLines = 10,
          modifier = Modifier
            .fillMaxWidth()
            .testTag("note_content_input"),
          shape = RoundedCornerShape(12.dp)
        )

        val words = if (content.isBlank()) 0 else content.trim().split(Regex("\\s+")).size
        Text(
          text = "$words words • ${content.length} chars",
          style = MaterialTheme.typography.labelSmall,
          color = MaterialTheme.colorScheme.outline
        )
      }
    },
    confirmButton = {
      Button(
        onClick = {
          if (title.isNotBlank()) {
            onSave(title.trim(), content.trim(), category)
          }
        },
        enabled = title.isNotBlank(),
        modifier = Modifier.testTag("save_note_dialog_button")
      ) {
        Text("Save Note", fontWeight = FontWeight.Bold)
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) {
        Text("Cancel")
      }
    }
  )
}

/**
 * 5. SETTING TAB:
 * Editable fields for Profile Name and Date of Birth (DOB) that successfully
 * save and load via SharedPreferences, Alarm trigger test, Dark/Light mode toggle, and App Version 1.0.0.
 */
@Composable
fun SettingTabContent(
  currentProfileName: String,
  currentProfileDob: String,
  isDarkMode: Boolean,
  onSaveProfile: (name: String, dob: String) -> Unit,
  onToggleDarkMode: (Boolean) -> Unit
) {
  val context = LocalContext.current

  var editedName by remember(currentProfileName) { mutableStateOf(currentProfileName) }
  var editedDob by remember(currentProfileDob) { mutableStateOf(currentProfileDob) }
  var showSavedFeedback by remember { mutableStateOf(false) }

  val calculatedAge = calculateAge(editedDob)

  val parsedDate = try {
    LocalDate.parse(editedDob)
  } catch (e: Exception) {
    LocalDate.of(1998, 5, 20)
  }

  val datePickerDialog = remember(context, parsedDate) {
    DatePickerDialog(
      context,
      { _, year, month, dayOfMonth ->
        val selectedMonth = month + 1
        val monthStr = if (selectedMonth < 10) "0$selectedMonth" else "$selectedMonth"
        val dayStr = if (dayOfMonth < 10) "0$dayOfMonth" else "$dayOfMonth"
        val newDate = "$year-$monthStr-$dayStr"
        editedDob = newDate
        onSaveProfile(editedName.trim(), newDate)
        showSavedFeedback = true
      },
      parsedDate.year,
      parsedDate.monthValue - 1,
      parsedDate.dayOfMonth
    ).apply {
      datePicker.maxDate = System.currentTimeMillis()
    }
  }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .verticalScroll(rememberScrollState())
      .padding(16.dp)
      .testTag("settings_tab_content"),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    // Section 1: Profile & Birthday
    Text(
      text = "PROFILE & BIRTHDAY",
      style = MaterialTheme.typography.labelMedium.copy(
        fontWeight = FontWeight.Bold,
        letterSpacing = 1.1.sp
      ),
      color = MaterialTheme.colorScheme.primary
    )

    Card(
      shape = RoundedCornerShape(16.dp),
      colors = CardDefaults.cardColors(
        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
      ),
      modifier = Modifier.fillMaxWidth()
    ) {
      Column(
        modifier = Modifier.padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
      ) {
        // Name input
        OutlinedTextField(
          value = editedName,
          onValueChange = {
            editedName = it
            showSavedFeedback = false
          },
          label = { Text("Profile Name") },
          leadingIcon = {
            Icon(Icons.Default.Person, contentDescription = "Profile Name", tint = MaterialTheme.colorScheme.primary)
          },
          singleLine = true,
          modifier = Modifier
            .fillMaxWidth()
            .testTag("setting_profile_name_input"),
          shape = RoundedCornerShape(12.dp)
        )

        // DOB Picker Tile
        Surface(
          shape = RoundedCornerShape(12.dp),
          color = MaterialTheme.colorScheme.surface,
          modifier = Modifier
            .fillMaxWidth()
            .clickable { datePickerDialog.show() }
            .testTag("setting_dob_picker_button")
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(horizontal = 14.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              modifier = Modifier.weight(1f)
            ) {
              Icon(
                imageVector = Icons.Default.Cake,
                contentDescription = "Date of birth",
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(24.dp)
              )
              Spacer(modifier = Modifier.width(12.dp))
              Column {
                Text(
                  text = "Date of Birth (DOB)",
                  style = MaterialTheme.typography.labelMedium,
                  color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                  text = if (calculatedAge != null) {
                    "${formatDob(editedDob)} • $calculatedAge yrs old"
                  } else {
                    formatDob(editedDob)
                  },
                  style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                  color = MaterialTheme.colorScheme.onSurface
                )
              }
            }

            Surface(
              shape = RoundedCornerShape(8.dp),
              color = MaterialTheme.colorScheme.primaryContainer
            ) {
              Text(
                text = "Change",
                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onPrimaryContainer,
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
              )
            }
          }
        }

        // Save Profile Action Button
        Button(
          onClick = {
            onSaveProfile(editedName.trim(), editedDob)
            showSavedFeedback = true
          },
          modifier = Modifier
            .fillMaxWidth()
            .testTag("save_profile_button"),
          shape = RoundedCornerShape(12.dp)
        ) {
          Icon(Icons.Default.Save, contentDescription = "Save Profile", modifier = Modifier.size(18.dp))
          Spacer(modifier = Modifier.width(8.dp))
          Text("Save Profile Changes", fontWeight = FontWeight.Bold)
        }

        if (showSavedFeedback) {
          Text(
            text = "✓ Profile details updated and saved to local storage",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.align(Alignment.CenterHorizontally)
          )
        }
      }
    }

    HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

    // Section 2: Habit Alarms & Notifications
    Text(
      text = "REMINDERS & ALARMS",
      style = MaterialTheme.typography.labelMedium.copy(
        fontWeight = FontWeight.Bold,
        letterSpacing = 1.1.sp
      ),
      color = MaterialTheme.colorScheme.primary
    )

    Card(
      shape = RoundedCornerShape(16.dp),
      colors = CardDefaults.cardColors(
        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
      ),
      modifier = Modifier.fillMaxWidth()
    ) {
      Column(
        modifier = Modifier.padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically
        ) {
          Icon(
            imageVector = Icons.Default.NotificationsActive,
            contentDescription = "Alarms Active",
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(24.dp)
          )
          Spacer(modifier = Modifier.width(12.dp))
          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = "Real Daily Alarms Active",
              style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )
            Text(
              text = "Exact alarms and notifications are automatically scheduled for each habit's reminder time.",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }

        OutlinedButton(
          onClick = {
            HabitNotificationHelper.showNotification(
              context = context,
              id = 9999,
              title = "⏰ Habit Reminder Alert!",
              message = "Daily Habit Checker: Your alarm and reminder system is active and running!"
            )
          },
          modifier = Modifier
            .fillMaxWidth()
            .testTag("test_alarm_button"),
          shape = RoundedCornerShape(12.dp)
        ) {
          Icon(
            imageVector = Icons.Default.AccessTime,
            contentDescription = "Test Notification",
            modifier = Modifier.size(18.dp)
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text("Trigger Test Alarm Notification", fontWeight = FontWeight.Bold)
        }
      }
    }

    HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

    // Section 3: Appearance
    Text(
      text = "APPEARANCE",
      style = MaterialTheme.typography.labelMedium.copy(
        fontWeight = FontWeight.Bold,
        letterSpacing = 1.1.sp
      ),
      color = MaterialTheme.colorScheme.primary
    )

    Card(
      shape = RoundedCornerShape(16.dp),
      colors = CardDefaults.cardColors(
        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
      ),
      modifier = Modifier.fillMaxWidth()
    ) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier.weight(1f)
        ) {
          Icon(
            imageVector = Icons.Default.NightlightRound,
            contentDescription = "Dark Theme",
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(24.dp)
          )
          Spacer(modifier = Modifier.width(12.dp))
          Column {
            Text(
              text = "Dark Theme",
              style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )
            Text(
              text = if (isDarkMode) "Dark theme enabled" else "Light theme enabled",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }

        Switch(
          checked = isDarkMode,
          onCheckedChange = onToggleDarkMode,
          modifier = Modifier.testTag("dark_mode_switch")
        )
      }
    }

    HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

    // Section 4: App Information & Version
    Text(
      text = "ABOUT",
      style = MaterialTheme.typography.labelMedium.copy(
        fontWeight = FontWeight.Bold,
        letterSpacing = 1.1.sp
      ),
      color = MaterialTheme.colorScheme.primary
    )

    Card(
      shape = RoundedCornerShape(16.dp),
      colors = CardDefaults.cardColors(
        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
      ),
      modifier = Modifier.fillMaxWidth()
    ) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(
            imageVector = Icons.Default.Info,
            contentDescription = "Version",
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(22.dp)
          )
          Spacer(modifier = Modifier.width(12.dp))
          Text(
            text = "App Version",
            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium)
          )
        }
        Text(
          text = "Version 1.0.0",
          style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
          color = MaterialTheme.colorScheme.primary
        )
      }
    }

    Spacer(modifier = Modifier.height(24.dp))
  }
}

/**
 * Add Habit Dialog with Category chips and native TimePickerDialog.
 */
@Composable
fun AddHabitDialog(
  context: Context,
  onDismiss: () -> Unit,
  onConfirm: (title: String, category: String, time: String) -> Unit
) {
  var title by remember { mutableStateOf("") }
  var selectedCategory by remember { mutableStateOf("Health") }
  var selectedTime by remember { mutableStateOf("07:00 AM") }

  val categories = listOf("Health", "Fitness", "Productivity", "Learning", "Mindfulness", "Finance")

  val timePickerDialog = remember(context) {
    TimePickerDialog(
      context,
      { _, hourOfDay, minute ->
        val amPm = if (hourOfDay >= 12) "PM" else "AM"
        val hour12 = when {
          hourOfDay == 0 -> 12
          hourOfDay > 12 -> hourOfDay - 12
          else -> hourOfDay
        }
        val minStr = if (minute < 10) "0$minute" else "$minute"
        val hourStr = if (hour12 < 10) "0$hour12" else "$hour12"
        selectedTime = "$hourStr:$minStr $amPm"
      },
      7,
      0,
      false
    )
  }

  AlertDialog(
    onDismissRequest = onDismiss,
    title = {
      Text(text = "New Daily Habit", fontWeight = FontWeight.Bold)
    },
    text = {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(14.dp)
      ) {
        OutlinedTextField(
          value = title,
          onValueChange = { title = it },
          label = { Text("Habit Title") },
          placeholder = { Text("e.g., Read 20 pages") },
          singleLine = true,
          modifier = Modifier
            .fillMaxWidth()
            .testTag("habit_title_input"),
          shape = RoundedCornerShape(12.dp)
        )

        // Time Picker Button
        Text(
          text = "Reminder Time",
          style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
        )
        Surface(
          shape = RoundedCornerShape(10.dp),
          color = MaterialTheme.colorScheme.surfaceVariant,
          modifier = Modifier
            .fillMaxWidth()
            .clickable { timePickerDialog.show() }
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(
                imageVector = Icons.Default.AccessTime,
                contentDescription = "Time",
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(20.dp)
              )
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = selectedTime,
                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
              )
            }
            Text(
              text = "Change",
              style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
              color = MaterialTheme.colorScheme.primary
            )
          }
        }

        // Category Chips
        Text(
          text = "Category",
          style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
        )
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState()),
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          categories.forEach { category ->
            val isSelected = selectedCategory == category
            Surface(
              shape = RoundedCornerShape(8.dp),
              color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
              modifier = Modifier.clickable { selectedCategory = category }
            ) {
              Text(
                text = category,
                style = MaterialTheme.typography.labelSmall.copy(
                  fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                ),
                color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
              )
            }
          }
        }
      }
    },
    confirmButton = {
      Button(
        onClick = {
          if (title.isNotBlank()) {
            onConfirm(title.trim(), selectedCategory, selectedTime)
          }
        },
        enabled = title.isNotBlank(),
        modifier = Modifier.testTag("save_habit_dialog_button")
      ) {
        Text("Add Habit", fontWeight = FontWeight.Bold)
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) {
        Text("Cancel")
      }
    }
  )
}
