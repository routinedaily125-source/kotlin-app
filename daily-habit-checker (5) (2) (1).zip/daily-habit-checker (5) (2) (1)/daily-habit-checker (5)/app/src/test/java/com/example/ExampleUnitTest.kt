package com.example

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {
  @Test
  fun addition_isCorrect() {
    assertEquals(4, 2 + 2)
  }

  @Test
  fun habit_toggleState_updatesCorrectly() {
    val habit = Habit(
      id = "1",
      title = "Drink Water",
      time = "08:00 AM",
      category = "Health",
      isCompleted = false
    )
    val updated = habit.copy(isCompleted = true)
    assertFalse(habit.isCompleted)
    assertTrue(updated.isCompleted)
  }

  @Test
  fun habit_iconResolution_detectsKeyCategories() {
    val waterIcon = getHabitIcon("Drink Water")
    val exerciseIcon = getHabitIcon("Morning Exercise")
    val readIcon = getHabitIcon("Read Book")
    val otherIcon = getHabitIcon("Practice Guitar")

    assertTrue(waterIcon.name.contains("WaterDrop"))
    assertTrue(exerciseIcon.name.contains("FitnessCenter"))
    assertTrue(readIcon.name.contains("MenuBook"))
    assertTrue(otherIcon.name.contains("CheckCircle"))
  }
}
